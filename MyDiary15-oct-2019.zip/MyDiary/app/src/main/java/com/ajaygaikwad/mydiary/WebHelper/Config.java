package com.ajaygaikwad.mydiary.WebHelper;

public class Config
{

    private  static String ipAddress= "https://engineerinside.000webhostapp.com/diary/androidWebservices/buildappservice_appoint/";

    public static String ip_image_address = "https://engineerinside.000webhostapp.com/diary/androidWebservices/buildappservice_appoint/images/";

    public static String SIGN_IN=ipAddress+"app_login_appoint.php";
    public static String REGISTRATION=ipAddress+"registration.php";
    public static String ADD_APPOINTMENT=ipAddress+"add_appointment.php";
    public static String GET_DEALER=ipAddress+"getDealer.php";
    public static String GET_APPOINTMENT=ipAddress+"getAppointment.php";
    public static String GET_APPOINTMENT_BTW_DATE=ipAddress+"getAppointBtwDate.php";
    public static String GET_DATE_DETAIL=ipAddress+"getDateDetails.php";
    public static String DELETE_PROP=ipAddress+"delete_appointment.php";
    public static String GET_PROP_FROM_IDs=ipAddress+"getPropFromId.php";
    public static String URL_APPUpdator=ipAddress+"isUpdateAvail.php";
}
