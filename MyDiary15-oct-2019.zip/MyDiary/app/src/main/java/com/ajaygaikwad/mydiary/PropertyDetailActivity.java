package com.ajaygaikwad.mydiary;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.ajaygaikwad.mydiary.Adapter.Adapter_Flat_Images;
import com.ajaygaikwad.mydiary.WebHelper.Config;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;


public class PropertyDetailActivity extends AppCompatActivity {
    TextView name_owner,owner_no,address_prop,address_prop2,area_sqmt,prop_price,des_kit,des_bath,des_bed,des_hall,des_other,o_name,o_no,tt_soc_name,prop_type;


    ImageView flat_img;
    String details,image1,image2,image3,image4,bhk,soc_name,flat_type;
    SharedPreferences preferences;
    Button intrest_btn;
    private ProgressDialog progressBar;
    private int progressBarStatus;
    String PropID;
    LinearLayout ll_kit,ll_bath,ll_bed,ll_hall,ll_area,ll_soc_name;
    ImageView imgcall;
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static final Integer[] XMEN = new Integer[0];
    private ArrayList<Integer> XMENArray = new ArrayList<Integer>();
    String[] imageUrls;
    ArrayList<String> imagearray = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_property_detail);
        preferences= PreferenceManager.getDefaultSharedPreferences(this);
        setTitle("Property Details");
        //setupToolBar();
        init();
        //bhk=new AllSharedPrefrences(getApplicationContext()).getBhk();
        soc_name=preferences.getString("soc_name","");
        flat_type=preferences.getString("flat_type","");


    }

    private void init() {
        address_prop=findViewById(R.id.address_prop);
        des_bath=findViewById(R.id.des_bath);
        des_bed=findViewById(R.id.des_bed);
        des_kit=findViewById(R.id.des_kit);
        des_hall=findViewById(R.id.des_hall);
        des_other=findViewById(R.id.des_other);
        area_sqmt=findViewById(R.id.area_sqmt);
        prop_price=findViewById(R.id.prop_price);
        intrest_btn=findViewById(R.id.intrest_btn);
        ll_kit=findViewById(R.id.ll_kit);
        ll_bath=findViewById(R.id.ll_bath);
        ll_bed=findViewById(R.id.ll_bed);
        ll_hall=findViewById(R.id.ll_hall);
        ll_area=findViewById(R.id.ll_area);
        o_name=findViewById(R.id.o_name);
        o_no=findViewById(R.id.o_no);
        imgcall=findViewById(R.id.imgcall);
        address_prop2=findViewById(R.id.address_prop2);
        ll_soc_name=findViewById(R.id.ll_soc_name);
        tt_soc_name=findViewById(R.id.tt_soc_name);
        prop_type=findViewById(R.id.prop_type);

        prop_type.setText(preferences.getString("owner_prop_type", ""));

        switch (preferences.getString("owner_prop_type", "")){

            case "Flat" :
                ll_kit.setVisibility(View.VISIBLE);
                ll_hall.setVisibility(View.VISIBLE);
                ll_bed.setVisibility(View.VISIBLE);
                ll_bath.setVisibility(View.VISIBLE);
                break;
            case "House" :
                ll_kit.setVisibility(View.VISIBLE);
                ll_hall.setVisibility(View.VISIBLE);
                ll_bed.setVisibility(View.VISIBLE);
                ll_bath.setVisibility(View.VISIBLE);
                break;
            case "Shop on Rent" :
                ll_area.setVisibility(View.GONE);
                break;
            case "Hall on Rent" :
                ll_area.setVisibility(View.GONE);
                break;
            case "Room on Rent" :
                ll_area.setVisibility(View.GONE);
                break;



        }

        mPager=findViewById(R.id.pager);

        image1 = preferences.getString("owner_image_one","");
        image2 = preferences.getString("owner_image_two","");
        image3 = preferences.getString("owner_image_three","");
        image4 = preferences.getString("owner_image_four","");
        //  name_owner.setText(preferences.getString("owner_name",""));
        //   owner_no.setText(preferences.getString("owner_mobile",""));
        address_prop.setText(preferences.getString("owner_prop_address",""));
        address_prop2.setText(preferences.getString("owner_full_address",""));
        o_name.setText(preferences.getString("owner_name",""));
        o_no.setText(preferences.getString("owner_mobile",""));
        area_sqmt.setText(preferences.getString("owner_area_sqft","")+" sqft");

        if(preferences.getString("selectedPropType", "").equals("Farm")){
            area_sqmt.setText(preferences.getString("owner_area_sqft","")+" acre");
        }
        prop_price.setText(preferences.getString("owner_actual_price",""));

        des_bath.setText(preferences.getString("owner_des_bath",""));
        des_bed.setText(preferences.getString("owner_des_bed",""));
        des_kit.setText(preferences.getString("owner_des_kit",""));
        des_hall.setText(preferences.getString("owner_des_hall",""));
        des_other.setText(preferences.getString("owner_description",""));

        ArrayList<String> images = new ArrayList<String>();
        images.add(Config.ip_image_address+image1);
        images.add(Config.ip_image_address+image2);
        images.add(Config.ip_image_address+image3);
        images.add(Config.ip_image_address+image4);


        for (int i = 0; i<images.size();i++){
            imagearray.add(images.get(i));
        }

        imgcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent in = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", preferences.getString("owner_mobile",""), null));
                startActivity(in);

            }
        });
        scroll_image(); }


    private void scroll_image() {

        for(int i=0;i<XMEN.length;i++)
            XMENArray.add(XMEN[i]);

        final ViewPager viewPager1 = findViewById(R.id.pager1);
        Adapter_Flat_Images adapter1 = new Adapter_Flat_Images(this, imagearray);
        viewPager1.setAdapter(adapter1);
        CircleIndicator indicator1 = (CircleIndicator)findViewById(R.id.indicator1);
        indicator1.setViewPager(viewPager1);

        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == XMEN.length) {
                    currentPage = 0;
                }
                viewPager1.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 10000, 10000);

    }

}
