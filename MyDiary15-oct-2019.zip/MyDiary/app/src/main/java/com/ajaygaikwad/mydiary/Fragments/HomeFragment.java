package com.ajaygaikwad.mydiary.Fragments;


import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.Classes.SharedPref;
import com.ajaygaikwad.mydiary.MainActivity;
import com.ajaygaikwad.mydiary.MainNavActivity;
import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import es.dmoral.toasty.Toasty;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    String url,firstName;

    LinearLayout updateLL;
    Button updateLeter,updateDownload;
    TextView tvAdd,tvView,tvToday,tvMonth,tvDayWish;

    private AdView mAdView;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_home, container, false);
        preferences= PreferenceManager.getDefaultSharedPreferences(getContext());
        editor=preferences.edit();
        //MobileAds.initialize(getActivity(), "ca-app-pub-3864681863166960~2667252138");

       /* MobileAds.initialize(getActivity(), new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = v.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);*/

        updateLL=v.findViewById(R.id.updateLL);
        updateLeter=v.findViewById(R.id.updateLeter);
        updateDownload=v.findViewById(R.id.updateDownload);
        tvAdd=v.findViewById(R.id.tvAdd);
        tvView=v.findViewById(R.id.tvView);
        tvToday=v.findViewById(R.id.tvToday);
        tvMonth=v.findViewById(R.id.tvMonth);
        tvDayWish=v.findViewById(R.id.tvDayWish);
        String name = new SharedPref(getActivity()).getUserName();
        String[] splitName = name.split(" ");
        if(splitName.length>1){
            firstName =splitName[0];
        }else{
            firstName = name;
        }





        String ss = preferences.getString("UpdateLL", "");
        if(ss.equals("1")){
            updateLL.setVisibility(View.VISIBLE);
        }else{
            updateLL.setVisibility(View.GONE);
        }

        updateLeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateLL.setVisibility(View.GONE);
            }
        });
        updateDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("UpdateLL","0");
                editor.commit();

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getResources().getString(R.string.urll)));
                startActivity(intent);

            }
        });

        geturl();

        tvAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.fmain,  new AddAppointmentFragment()).addToBackStack("").commit();
            }
        });
        tvMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new AllAppointmentFragment2();
                Bundle bundle = new Bundle();
                bundle.putString("viewDetails", "month");
                fragment.setArguments(bundle);
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.fmain,  fragment).addToBackStack("").commit();
            }
        });
        tvView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new AllAppointmentFragment2();
                Bundle bundle = new Bundle();
                bundle.putString("viewDetails", "all");
                fragment.setArguments(bundle);
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.fmain,  fragment).addToBackStack("").commit();
            }
        });
        tvToday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new AllAppointmentFragment2();
                Bundle bundle = new Bundle();
                bundle.putString("viewDetails", "today");
                fragment.setArguments(bundle);
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.fmain,  fragment).addToBackStack("").commit();
            }
        });

        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        dayWish(hour);

        return v;


    }


    public void dayWish(int hour){

        int flag = 0;
        if (hour < 4 && flag == 0) {
            flag = 1;
            tvDayWish.setText("Good Night " + firstName + "!");
        }

        if (hour < 12 && flag == 0) {
            flag = 1;
            tvDayWish.setText("Good Morning " + firstName + "!");
        }
        if (hour < 16 && flag == 0) {
            flag = 1;
            tvDayWish.setText("Good Afternoon " + firstName + "!");
        }

        if (hour < 24 && flag == 0) {
            flag = 1;
            tvDayWish.setText("Good Evening " + firstName + "!");
        }
    }



    public void  onResume(){
        super.onResume();
        ((MainNavActivity)getActivity()).setActionBarTitle("Home");
    }


    private void geturl() {

        StringRequest postreq = new StringRequest(Request.Method.POST, Config.GET_DEALER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    //progressBar.dismiss();
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("jsonUrl");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject j1 = jsonArray.getJSONObject(i);
                         url = j1.getString("name");


                    }
                    if(url.equals("banned") || url.equals("logout")){
                        new SharedPref(getActivity()).clearPref();
                        Intent in = new Intent(getActivity(), MainActivity.class);
                        startActivity(in);
                        getActivity().finish();
                    }




                } catch (Exception e1) {
                    //progressBar.dismiss();
                    Toasty.error(getActivity(), "Error retrive Url").show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //progressBar.dismiss();
                Toasty.error(getActivity(), "Error Connecting To Server").show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                //map.put("sno", editsno.getText().toString());
                map.put("mobile",new SharedPref(getActivity()).getMobile());

                return map;
            }
        };
        MyApplication.getInstance().addToReqQueue(postreq);

    }

}
