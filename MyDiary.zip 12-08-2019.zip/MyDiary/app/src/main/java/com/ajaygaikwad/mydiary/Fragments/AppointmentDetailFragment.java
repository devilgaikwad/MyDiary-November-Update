package com.ajaygaikwad.mydiary.Fragments;


import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.ajaygaikwad.mydiary.Adapter.AdapterDateDetails;
import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.MainNavActivity;
import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.ajaygaikwad.mydiary.pojo.DetailsItem;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class AppointmentDetailFragment extends Fragment {

    private ProgressDialog progressBar;
    private int progressBarStatus;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    RecyclerView recyclerView;
    List<DetailsItem> list1;
    AdapterDateDetails adapterDateDetails;
    LinearLayout linearlayout1,linearlayout2;
    String nodata="";
    SwipeRefreshLayout swipeRefreshLayout;

    public AppointmentDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=  inflater.inflate(R.layout.fragment_appointment_detail, container, false);
        preferences= PreferenceManager.getDefaultSharedPreferences(getActivity());
        editor=preferences.edit();
        linearlayout1=v.findViewById(R.id.linearlayout1);
        linearlayout2=v.findViewById(R.id.linearlayout2);
        recyclerView = v.findViewById(R.id.recycler_view);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        swipeRefreshLayout = (SwipeRefreshLayout) v.findViewById(R.id.swiperefresh);

        list1 = new ArrayList<DetailsItem>();
        setHasOptionsMenu(true);
        getDetails();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                adapterDateDetails.clear();
                adapterDateDetails.notifyDataSetChanged();
                getDetails();
                nodata="";
            }
        });
    return v;}
    
    private void getDetails(){
        progressDiaglog();
        StringRequest postRequest1 = new StringRequest(Request.Method.POST, Config.GET_DATE_DETAIL,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response) {
                        try {
                            if (swipeRefreshLayout.isRefreshing()) {
                                swipeRefreshLayout.setRefreshing(false);
                            }
                            progressBar.dismiss();
                            JSONObject object=new JSONObject(response);
                            JSONArray jsonArray = object.getJSONArray("details");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject j1 = jsonArray.getJSONObject(i);
                                String  srno = j1.getString("srno");
                                String  date = j1.getString("date");
                                String  dealerName = j1.getString("dealer_name");
                                String  customerName = j1.getString("customer_name");
                                String  customerMobile = j1.getString("customer_mobile");
                                String  propType = j1.getString("prop_type");
                                String  propId = j1.getString("prop_id");
                                String  description = j1.getString("description");
                                String  city = j1.getString("city");
                                nodata="1";

                                DetailsItem obj = new DetailsItem(srno,date,customerMobile,propId,city,dealerName,description,customerName,propType);
                                list1.add(obj);

                            }
                            if(nodata.equals("")){
                                linearlayout1.setVisibility(View.GONE);
                                linearlayout2.setVisibility(View.VISIBLE);
                            }
                            adapterDateDetails=new AdapterDateDetails(getActivity(),list1);
                            recyclerView.setAdapter(adapterDateDetails);


                        }
                        catch (Exception e) {
                            if (swipeRefreshLayout.isRefreshing()) {
                                swipeRefreshLayout.setRefreshing(false);
                            }
                            progressBar.dismiss();
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "No Details on this date", Toast.LENGTH_SHORT).show();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (swipeRefreshLayout.isRefreshing()) {
                    swipeRefreshLayout.setRefreshing(false);
                }
                progressBar.dismiss();
                Toast.makeText(getActivity(),"Error Connecting To Server", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                //params.put("name",et_name.getText().toString());
                params.put("date", preferences.getString("SelecterDate",""));

                //params.put("firebase_id",firebase_id);

                return params;
            }
        };

        // Adding request to request queue
        RetryPolicy policy = new DefaultRetryPolicy(90000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest1.setRetryPolicy(policy);
        postRequest1.setShouldCache(false);
        MyApplication.getInstance().addToReqQueue(postRequest1);

    }

    public void progressDiaglog(){

        progressBar = new ProgressDialog(getActivity());
        progressBar.setCancelable(false);
        progressBar.setMessage(getString(R.string.pleaseWait));
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
    }

    public void onResume(){
        super.onResume();
        ((MainNavActivity)getActivity()).setActionBarTitle( preferences.getString("SelecterDate",""));
    }
}