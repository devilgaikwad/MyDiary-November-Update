package com.ajaygaikwad.mydiary.Fragments;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.MainNavActivity;
import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_home, container, false);
        preferences= PreferenceManager.getDefaultSharedPreferences(getContext());
        editor=preferences.edit();
            geturl();
        return v;
    }


    public void  onResume(){
        super.onResume();
        ((MainNavActivity)getActivity()).setActionBarTitle("Home");
    }


    private void geturl() {

        StringRequest postreq = new StringRequest(Request.Method.POST, Config.GET_DEALER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    //progressBar.dismiss();
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("jsonUrl");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject j1 = jsonArray.getJSONObject(i);
                        String url = j1.getString("name");

                        editor.putString("URL", url);
                        editor.commit();

                    }




                } catch (Exception e1) {
                    //progressBar.dismiss();
                    Toast.makeText(getActivity(), "Error retrive Url", Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //progressBar.dismiss();
                Toast.makeText(getActivity(), "Error Connecting To Server", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                //map.put("sno", editsno.getText().toString());
                //map.put("filtered_price",filtered_price);

                return map;
            }
        };
        MyApplication.getInstance().addToReqQueue(postreq);

    }

}
