package com.ajaygaikwad.mydiary.WebHelper;

public class Config
{

    private  static String ipAddress= "https://engineerinside.000webhostapp.com/diary/androidWebservices/buildappservice_appoint/";

    //private  static String ipAddress= "http://18.221.224.87/buildapp/buildappservice_appoint/";

    public static String ip_image_address = "https://engineerinside.000webhostapp.com/diary/androidWebservices/images";

    //public static String ip_image_address = "http://18.221.224.87/buildapp/buildpanel/images/";

    public static String URL_SELECT_CITY=ipAddress+"city_selector.php";
    public static String SIGN_IN=ipAddress+"app_login_appoint.php";
    public static String ADD_APPOINTMENT=ipAddress+"add_appointment.php";
    public static String GET_DEALER=ipAddress+"getDealer.php";
    public static String GET_APPOINTMENT=ipAddress+"getAppointment.php";
    public static String GET_DATE_DETAIL=ipAddress+"getDateDetails.php";
    public static String DELETE_PROP=ipAddress+"delete_appointment.php";
    public static String UPDATE_DATE=ipAddress+"reSheduledDate.php";
    public static String GET_PROP_IDs=ipAddress+"getPropertyIDs.php";
    public static String GET_PROP_FROM_IDs=ipAddress+"getPropFromId.php";
}
