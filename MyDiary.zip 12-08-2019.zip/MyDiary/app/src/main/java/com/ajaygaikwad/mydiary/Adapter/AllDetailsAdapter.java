package com.ajaygaikwad.mydiary.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.pojo.AppointmentItem;
import com.ajaygaikwad.mydiary.pojo.DetailsItem;

import java.util.List;

public class AllDetailsAdapter extends RecyclerView.Adapter<AllDetailsAdapter.MyViewHolder> {
    List<AppointmentItem> list;
    Context context;
    public AllDetailsAdapter(Context context, List<AppointmentItem> list) {
        this.list=list;
        this.context=context;


    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_details, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        AppointmentItem pojo = list.get(position);
        holder.description.setText("Description = "+pojo.getDesc());
        holder.custoNo.setText("Amount = "+pojo.getCustNo());
        holder.dealerName.setText("Name = "+pojo.getDealerName());
        holder.date11.setText("Date = "+pojo.getDate());
        holder.type.setText("Type = "+pojo.getPropType());


        if(pojo.getPropType().equals("Credit")){
            holder.cardID.setBackgroundResource(R.color.greenn);
        }else if(pojo.getPropType().equals("Expense")){
            holder.cardID.setBackgroundResource(R.color.redd);
        }else{
            holder.cardID.setBackgroundResource(R.color.purplee);
        }

    }



    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView dealerName,custoName,propID,custoNo,description,date11,type;
        ImageView imgCall;
        CardView cardID;
        Button reshedule_prop,delete_prop;

        public MyViewHolder(View itemView) {

            super(itemView);

            dealerName=itemView.findViewById(R.id.dealerName);

            custoNo=itemView.findViewById(R.id.custoNo);

            description=itemView.findViewById(R.id.description);
            cardID=itemView.findViewById(R.id.cardID);
            reshedule_prop=itemView.findViewById(R.id.reshedule_prop);
            delete_prop=itemView.findViewById(R.id.delete_prop);
            date11=itemView.findViewById(R.id.date11);
            type=itemView.findViewById(R.id.type);
            reshedule_prop.setVisibility(View.GONE);
            delete_prop.setVisibility(View.GONE);
        }
    }
}
