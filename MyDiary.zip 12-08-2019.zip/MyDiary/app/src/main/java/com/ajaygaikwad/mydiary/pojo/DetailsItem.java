package com.ajaygaikwad.mydiary.pojo;

public class DetailsItem{
	private String srno;
	private String date;
	private String customerMobile;
	private String propId;
	private String city;
	private String dealerName;
	private String description;
	private String customerName;
	private String propType;


	public DetailsItem(String srno,String date, String customerMobile, String propId, String city, String dealerName, String description, String customerName, String propType) {
		this.srno = srno;
		this.date = date;
		this.customerMobile = customerMobile;
		this.propId = propId;
		this.city = city;
		this.dealerName = dealerName;
		this.description = description;
		this.customerName = customerName;
		this.propType = propType;
	}


	public void setSrno(String srno){
		this.srno = srno;
	}

	public String getSrno(){
		return srno;
	}

	public void setDate(String date){
		this.date = date;
	}

	public String getDate(){
		return date;
	}

	public void setCustomerMobile(String customerMobile){
		this.customerMobile = customerMobile;
	}

	public String getCustomerMobile(){
		return customerMobile;
	}

	public void setPropId(String propId){
		this.propId = propId;
	}

	public String getPropId(){
		return propId;
	}

	public void setCity(String city){
		this.city = city;
	}

	public String getCity(){
		return city;
	}

	public void setDealerName(String dealerName){
		this.dealerName = dealerName;
	}

	public String getDealerName(){
		return dealerName;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setCustomerName(String customerName){
		this.customerName = customerName;
	}

	public String getCustomerName(){
		return customerName;
	}

	public void setPropType(String propType){
		this.propType = propType;
	}

	public String getPropType(){
		return propType;
	}
}
