package com.ajaygaikwad.mydiary.Fragments;


import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.Classes.SharedPref;
import com.ajaygaikwad.mydiary.MainNavActivity;
import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddAppointmentFragment extends Fragment {
    View v;
    String onlyDate;

    TextView dateSelected;
    List<String>propList;
    AutoCompleteTextView nameAuto;
    Spinner bTypeSpinner;
    EditText et_desc,et_amount;
    Button btn_add;
    private ProgressDialog progressBar;
    private int progressBarStatus;
    private DatePickerDialog.OnDateSetListener mdateSetListener;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    String result22;
    String businessType;
    String date;
    String timeStamp;
    public AddAppointmentFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_add_appointment, container, false);
        preferences= PreferenceManager.getDefaultSharedPreferences(getActivity());
        editor= preferences.edit();
        dateSelected = v.findViewById(R.id.dateselect);




        bTypeSpinner=v.findViewById(R.id.bTypeSpinner);
        nameAuto=v.findViewById(R.id.nameAuto);
        et_desc=v.findViewById(R.id.et_desc);
        btn_add=v.findViewById(R.id.btn_add);
        et_amount=v.findViewById(R.id.et_amount);

        propList = new ArrayList<>();


        propList.clear();
        list();
        ArrayAdapter <String> propAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,propList);
        bTypeSpinner.setAdapter(propAdapter);



         bTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
             @Override
             public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                 businessType = bTypeSpinner.getItemAtPosition(bTypeSpinner.getSelectedItemPosition()).toString();
             }

             @Override
             public void onNothingSelected(AdapterView<?> adapterView) {

             }
         });

        dateSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar cal = Calendar.getInstance();
                final int year = cal.get(Calendar.YEAR);
                final int month = cal.get(Calendar.MONTH);
                final int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog
                        (getActivity(), mdateSetListener,
                                year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                //dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                dialog.show();
            }
        });

        timeStamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
        mdateSetListener= new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month=month+1;

                date =year+"-"+month+"-"+day;
                String date1 =day+"/"+month+"/"+year;
                dateSelected.setText(date1+" "+timeStamp);
                onlyDate= date;
            }
        };


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addAppointMethod();
            }
        });
        
        return v;
    }

    private void addAppointMethod() {

        if(dateSelected.getText().toString().equals("Select Date")){
            Snackbar snake = Snackbar.make(getView()," Please Select Date" , Snackbar.LENGTH_SHORT);
            snake.show();
            return;
        }
        if(nameAuto.getText().toString().equals("")){
            Snackbar snake = Snackbar.make(getView()," Please Add Name" , Snackbar.LENGTH_SHORT);
            snake.show();

            nameAuto.setError("Enter Name");
            return;
        }
        if(businessType.equals("Setect Type")){
            Snackbar snake = Snackbar.make(getView()," Please Select Type" , Snackbar.LENGTH_SHORT);
            snake.show();
            return;
        }

        if(et_amount.getText().toString().trim().equals("")){
            Snackbar snake = Snackbar.make(getView()," Please Enter Amount" , Snackbar.LENGTH_SHORT);
            snake.show();
            et_amount.setError("Enter Amount");
            return;
        }

        progressDiaglog();
        StringRequest postRequest1 = new StringRequest(Request.Method.POST, Config.ADD_APPOINTMENT,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            progressBar.dismiss();
                            JSONObject object = new JSONObject(response);
                             result22 = object.getString("success");


                            if (result22.equals("1")) {
                                Toast.makeText(getActivity(), "Added to Diary Successfully", Toast.LENGTH_SHORT).show();
                                AlertBox();
                            }

                            else {
                                progressBar.dismiss();
                                AlertBox();
                                Toast.makeText(getActivity(), "Diary Set Error", Toast.LENGTH_SHORT).show();
                            }


                        } catch (Exception e) {
                            progressBar.dismiss();
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "Error...", Toast.LENGTH_SHORT).show();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
                    {
                progressBar.dismiss();
                Toast.makeText(getActivity(), "Error Connecting To Server", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                //params.put("name",et_name.getText().toString());
                params.put("date", date+" "+timeStamp);
                params.put("dealerName",nameAuto.getText().toString());
                params.put("propType",businessType);
                params.put("custoNo",et_amount.getText().toString());
                params.put("desc",et_desc.getText().toString());
                params.put("onlyDate",onlyDate);
                params.put("city", new SharedPref(getActivity()).getCity());

                //params.put("firebase_id",firebase_id);

                return params;
            }
        };

        RetryPolicy policy = new DefaultRetryPolicy(90000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest1.setRetryPolicy(policy);
        postRequest1.setShouldCache(false);
        MyApplication.getInstance().addToReqQueue(postRequest1);
    }


    private void AlertBox() {
        if(result22.equals("1")) {
            try {
                final SweetAlertDialog pDialog = new SweetAlertDialog(getActivity(), SweetAlertDialog.SUCCESS_TYPE);
                pDialog.setTitle("Successfully Added");
                pDialog.setContentText("Successfully added to diary");
                pDialog.show();
                pDialog.setConfirmButton("Okey", new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        pDialog.dismissWithAnimation();
                        FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                        ft.replace(R.id.fmain, new HomeFragment()).commit();

                    }
                });
            } catch (Exception e) {
            }
        }else{
            try {
                final SweetAlertDialog pDialog = new SweetAlertDialog(getActivity(), SweetAlertDialog.ERROR_TYPE);
                pDialog.setTitle("Error");
                if(result22.equals("2")){
                    pDialog.setContentText("Appointment already added for this user");
                }else{
                    pDialog.setContentText("Error while adding appointment");
                }
                pDialog.show();
                pDialog.setConfirmButton("Okey", new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        pDialog.dismissWithAnimation();
                    }
                });
            } catch (Exception e) {
            }
        }

    }

    public void progressDiaglog(){
        progressBar = new ProgressDialog(getActivity());
        progressBar.setCancelable(false);
        progressBar.setMessage(getString(R.string.pleaseWait));
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
    }

    private void list() {
        propList.add("Setect Type");
        propList.add("Credit");
        propList.add("Expense");
        propList.add("Borrow");

    }

    

    
    public void onResume(){
        super.onResume();
        ((MainNavActivity)getActivity()).setActionBarTitle("Add to Diary");
    }

}
