package com.ajaygaikwad.mydiary.Fragments;


import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.Toast;

import com.ajaygaikwad.mydiary.Adapter.AllDetailsAdapter;
import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.ajaygaikwad.mydiary.pojo.AppointmentItem;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class AllAppointmentFragment extends Fragment {

    RecyclerView recycler_view_all_appointment;
    List<AppointmentItem> list ;
    AllDetailsAdapter allDetailsAdapter;

    private ProgressDialog progressBar;
    private int progressBarStatus;



    public AllAppointmentFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_all_appointment, container, false);
        recycler_view_all_appointment=v.findViewById(R.id.recycler_view_all_appointment);
        list=new ArrayList<AppointmentItem>();
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recycler_view_all_appointment.setLayoutManager(mLayoutManager);

        Button calenderView = v.findViewById(R.id.calenderView);
        calenderView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.replace(R.id.fmain,  new ViewAppointFragment()).addToBackStack("tag").commit();
            }
        });
        getAllData();

        return v;
    }

    public void progressDiaglog(){

        progressBar = new ProgressDialog(getActivity());
        progressBar.setCancelable(false);
        progressBar.setMessage(getString(R.string.pleaseWait));
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
    }

    private void getAllData() {
        progressDiaglog();

        StringRequest postreq = new StringRequest(Request.Method.POST, Config.GET_APPOINTMENT, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    progressBar.dismiss();
                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("appointment");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject j1 = jsonArray.getJSONObject(i);
                        String date = j1.getString("date");
                        String name = j1.getString("dealer_name");
                        String amount = j1.getString("cust_no");
                        String businessType = j1.getString("prop_type");
                        String desc = j1.getString("desc");
                        String city = j1.getString("city");

                        ///datesList.add(date);

                        AppointmentItem obj = new AppointmentItem(date, name,  amount,  businessType,  desc,  city);
                        list.add(obj);
                    }
                    allDetailsAdapter = new AllDetailsAdapter(getActivity(),list);
                    recycler_view_all_appointment.setAdapter(allDetailsAdapter);
                    //setCustomdate();

                } catch (Exception e1) {
                    progressBar.dismiss();
                    Toast.makeText(getActivity(), "Error retrive Data", Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.dismiss();

                Toast.makeText(getActivity(), "Error Connecting to server", Toast.LENGTH_SHORT).show();
                //alertBox();

            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                //map.put("sno", editsno.getText().toString());
                //  map.put("filtered_price",filtered_price);

                return map;
            }
        };
        MyApplication.getInstance().addToReqQueue(postreq);

    }

}
