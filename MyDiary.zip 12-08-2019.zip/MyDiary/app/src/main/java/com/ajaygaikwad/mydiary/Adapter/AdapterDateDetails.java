package com.ajaygaikwad.mydiary.Adapter;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.MainNavActivity;
import com.ajaygaikwad.mydiary.R;
import com.ajaygaikwad.mydiary.ViewPropDetailsActivity;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.ajaygaikwad.mydiary.pojo.DetailsItem;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class AdapterDateDetails extends RecyclerView.Adapter<AdapterDateDetails.MyViewHolder> {

    Context context;
    List<DetailsItem> list1;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    private ProgressDialog progressBar;
    private int progressBarStatus;
    DetailsItem pojo;
    String result11="0";
    onClick onClick;
    private DatePickerDialog.OnDateSetListener mdateSetListener;
    String dateSelected;

    public AdapterDateDetails(Context context, List<DetailsItem> list1) {
        this.context=context;
        this.list1=list1;
        preferences= PreferenceManager.getDefaultSharedPreferences(context);
        editor=preferences.edit();

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_details, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, int position) {
        pojo = list1.get(position);
        holder.description.setText("Description = "+pojo.getDescription());
        holder.custoNo.setText("Amount = "+pojo.getCustomerMobile());
        holder.date11.setText("Date = "+pojo.getDate());
        holder.dealerName.setText("Name = "+pojo.getDealerName());
        holder.type.setText("Type = "+pojo.getPropType());

        if(pojo.getPropType().equals("Credit")){
            holder.cardID.setBackgroundResource(R.color.greenn);
        }else if(pojo.getPropType().equals("Expense")){
            holder.cardID.setBackgroundResource(R.color.redd);
        }else{
            holder.cardID.setBackgroundResource(R.color.purplee);
        }

        holder.reshedule_prop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Calendar cal = Calendar.getInstance();
                        final int year = cal.get(Calendar.YEAR);
                        final int month = cal.get(Calendar.MONTH);
                        final int day = cal.get(Calendar.DAY_OF_MONTH);
                        DatePickerDialog dialog = new DatePickerDialog
                                (context, mdateSetListener,
                                        year, month, day);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
                        dialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                        dialog.show();
                //updateTime();
            }

        });

        final String timeStamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
        mdateSetListener= new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month=month+1;

                String date =year+"-"+month+"-"+day;
                dateSelected = date+" "+timeStamp;
                holder.date11.setText("Update Date = "+date+" "+timeStamp);
                AlertBox1();
            }
        };
        holder.delete_prop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    final SweetAlertDialog pDialog = new SweetAlertDialog(context, SweetAlertDialog.WARNING_TYPE);
                    pDialog.setContentText("Details Deleted Permenantly");
                    pDialog.setTitle("Confirm Delete");
                    pDialog.show();
                    pDialog.setCancelable(false);
                    pDialog.setConfirmButton("Confirm", new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            pDialog.dismissWithAnimation();
                            delete_prop_method();

                        }
                    });
                    pDialog.setCancelButton("Cancel", new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            pDialog.dismissWithAnimation();
                        }
                    });
                }catch (Exception e){
                    delete_prop_method();
                }
                //delete_prop_method();
            }
        });

    }

    private void AlertBox1() {

        final SweetAlertDialog pDialog = new SweetAlertDialog(context, SweetAlertDialog.WARNING_TYPE);
        pDialog.setTitle("Confirm Resheduled");
        pDialog.setContentText("Are you sure to resheduled appointment to '"+dateSelected+"'");
        pDialog.show();
        pDialog.setConfirmButton("Sure", new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                pDialog.dismissWithAnimation();
                updateTime();
            }
        });
        pDialog.setCancelable(false);
        pDialog.setCancelButton("Cancel", new SweetAlertDialog.OnSweetClickListener() {
            @Override
            public void onClick(SweetAlertDialog sweetAlertDialog) {
                pDialog.dismissWithAnimation();
            }
        });
    }


    @Override
    public int getItemCount() {
        return list1.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView dealerName,custoName,propID,custoNo,description,date11,type;
        ImageView imgCall;
        CardView cardID;
        Button reshedule_prop,delete_prop;
        public MyViewHolder(View itemView) {
            super(itemView);
            dealerName=itemView.findViewById(R.id.dealerName);
            custoNo=itemView.findViewById(R.id.custoNo);
            description=itemView.findViewById(R.id.description);
            cardID=itemView.findViewById(R.id.cardID);
            reshedule_prop=itemView.findViewById(R.id.reshedule_prop);
            delete_prop=itemView.findViewById(R.id.delete_prop);
            date11=itemView.findViewById(R.id.date11);
            type =itemView.findViewById(R.id.type);
        }
    }

    private void updateTime() {
        progressDiaglog();
        StringRequest postRequest1 = new StringRequest(Request.Method.POST, Config.UPDATE_DATE,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response) {
                        try {
                            progressBar.dismiss();
                            JSONObject object=new JSONObject(response);
                            result11 = object.getString("success");

                            if (result11.equals("1")) {
                                Toast.makeText(context, "Date Updated", Toast.LENGTH_SHORT).show();
                                AlertBox2("u1");

                            } else {
                                progressBar.dismiss();
                                Toast.makeText(context, " Date Updation Unsuccessfull", Toast.LENGTH_SHORT).show();
                            }

                        }
                        catch (Exception e) {
                            progressBar.dismiss();
                            e.printStackTrace();
                            //Toast.makeText(getActivity(), "No Appointment on this date", Toast.LENGTH_SHORT).show();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.dismiss();
                //Toast.makeText(getActivity(),"Error Connecting To Server", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                //params.put("name",et_name.getText().toString());
                params.put("date", dateSelected);
                params.put("srno", pojo.getSrno());


                return params;
            }
        };

        // Adding request to request queue
        RetryPolicy policy = new DefaultRetryPolicy(90000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest1.setRetryPolicy(policy);
        postRequest1.setShouldCache(false);
        MyApplication.getInstance().addToReqQueue(postRequest1);


    }

    private void AlertBox2(String sts) {
        try {

            final SweetAlertDialog pDialog = new SweetAlertDialog(context, SweetAlertDialog.SUCCESS_TYPE);
            if(sts.equals("d1")){
                pDialog.setTitle("Done");
                pDialog.setContentText("Delete successfully");
            }else{
                pDialog.setTitle("Done");
                pDialog.setContentText("Details resheduled successfully");
            }
            pDialog.setTitle("Done");
            pDialog.setContentText("Details resheduled successfully");
            pDialog.show();
            pDialog.setConfirmButton("Okey", new SweetAlertDialog.OnSweetClickListener() {
                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog) {
                    pDialog.dismissWithAnimation();
                    Intent in = new Intent(context, MainNavActivity.class);
                    context.startActivity(in);

                }
            });
        }catch (Exception e){
            Intent in = new Intent(context, MainNavActivity.class);
            context.startActivity(in);
        }
    }

    private void delete_prop_method() {

        progressDiaglog();
        StringRequest postRequest1 = new StringRequest(Request.Method.POST, Config.DELETE_PROP,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response) {
                        try {
                            progressBar.dismiss();
                            JSONObject object=new JSONObject(response);
                             result11 = object.getString("success");

                            if (result11.equals("1")) {
                                Toast.makeText(context, "Delete Successfully", Toast.LENGTH_SHORT).show();
                                AlertBox2("d1");



                            } else {
                                progressBar.dismiss();
                                Toast.makeText(context, " Delete Details Unsuccessfull", Toast.LENGTH_SHORT).show();
                            }

                        }
                        catch (Exception e) {
                            progressBar.dismiss();
                            e.printStackTrace();
                            //Toast.makeText(getActivity(), "No Appointment on this date", Toast.LENGTH_SHORT).show();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.dismiss();
                //Toast.makeText(getActivity(),"Error Connecting To Server", Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                //params.put("name",et_name.getText().toString());
                params.put("date", preferences.getString("SelecterDate",""));
                params.put("srno", pojo.getSrno());



                return params;
            }
        };

        // Adding request to request queue
        RetryPolicy policy = new DefaultRetryPolicy(90000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        postRequest1.setRetryPolicy(policy);
        postRequest1.setShouldCache(false);
        MyApplication.getInstance().addToReqQueue(postRequest1);

    }


    public void progressDiaglog(){

        progressBar = new ProgressDialog(context);
        progressBar.setCancelable(false);
        progressBar.setMessage(context.getString(R.string.pleaseWait));
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
    }

    public void clear(){
        list1.clear();
        notifyDataSetChanged();
    }

    public void setOnClickListenerAdapter(onClick onClick) {
        this.onClick = onClick;
    }

    public interface onClick {
        public void onItemClick(AdapterDateDetails adapterDateDetails);
    }

}
