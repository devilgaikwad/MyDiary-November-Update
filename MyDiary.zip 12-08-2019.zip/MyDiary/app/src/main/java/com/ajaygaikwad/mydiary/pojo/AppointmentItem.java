package com.ajaygaikwad.mydiary.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class AppointmentItem implements Parcelable {
	private String date;
	private String city;
	private String custNo;
	private String dealerName;
	private String propType;
	private String desc;

	public AppointmentItem(String date, String dealerName, String custNo, String propType, String desc, String city) {
		this.date = date;
		this.city = city;
		this.custNo = custNo;
		this.dealerName = dealerName;
		this.propType = propType;
		this.desc = desc;
	}


	protected AppointmentItem(Parcel in) {
		date = in.readString();
		city = in.readString();
		custNo = in.readString();
		dealerName = in.readString();
		propType = in.readString();
		desc = in.readString();
	}

	public static final Creator<AppointmentItem> CREATOR = new Creator<AppointmentItem>() {
		@Override
		public AppointmentItem createFromParcel(Parcel in) {
			return new AppointmentItem(in);
		}

		@Override
		public AppointmentItem[] newArray(int size) {
			return new AppointmentItem[size];
		}
	};

	public void setDate(String date){
		this.date = date;
	}

	public String getDate(){
		return date;
	}

	public void setCity(String city){
		this.city = city;
	}

	public String getCity(){
		return city;
	}

	public void setCustNo(String custNo){
		this.custNo = custNo;
	}

	public String getCustNo(){
		return custNo;
	}

	public void setDealerName(String dealerName){
		this.dealerName = dealerName;
	}

	public String getDealerName(){
		return dealerName;
	}

	public void setPropType(String propType){
		this.propType = propType;
	}

	public String getPropType(){
		return propType;
	}

	public void setDesc(String desc){
		this.desc = desc;
	}

	public String getDesc(){
		return desc;
	}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int i) {
		parcel.writeString(date);
		parcel.writeString(city);
		parcel.writeString(custNo);
		parcel.writeString(dealerName);
		parcel.writeString(propType);
		parcel.writeString(desc);
	}
}
