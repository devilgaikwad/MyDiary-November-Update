package com.ajaygaikwad.mydiary;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.Classes.SharedPref;
import com.ajaygaikwad.mydiary.Fragments.AboutUsFragment;
import com.ajaygaikwad.mydiary.Fragments.AddAppointmentFragment;
import com.ajaygaikwad.mydiary.Fragments.HomeFragment;
import com.ajaygaikwad.mydiary.Fragments.ViewAppointFragment;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import es.dmoral.toasty.Toasty;

public class MainNavActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    View hView;
    String currentDate,updateDate="";
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
//    private AdView adView;
//    AdRequest adRequest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_nav);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor = preferences.edit();
        /*adView = (AdView) findViewById(R.id.ad_view);
        adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);*/


        if(!new SharedPref(MainNavActivity.this).getLogin().equals("1")){
            Intent in = new Intent(MainNavActivity.this,SplashActivity.class);
            startActivity(in);
            finish();
            return;
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();



        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        hView=navigationView.getHeaderView(0);
        TextView nameNav=hView.findViewById(R.id.nameNav);
        TextView mobileNav=hView.findViewById(R.id.mobileNav);
        nameNav.setText(new SharedPref(getApplicationContext()).getUserName());
        mobileNav.setText(new SharedPref(getApplicationContext()).getMobile());

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fmain,  new HomeFragment()).addToBackStack("").commit();

        Calendar mcurrentTime = Calendar.getInstance();

        currentDate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        updateDate = preferences.getString("Date55","");
        if(!updateDate.equals(currentDate)){

            int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
            dayWish(hour);
            editor.putString("Date55",currentDate);
            editor.commit();

        }else{}

       /* if(!updateDate.equals(currentDate)){
            autoUpdator();

        }*/


    }

    public void dayWish(int hour){

        int flag = 0;
        if (hour < 4 && flag == 0) {
            flag = 1;
            showThoughts("1");
        }

        if (hour < 12 && flag == 0) {
            flag = 1;
            showThoughts("2");
        }
        if (hour < 16 && flag == 0) {
            flag = 1;
            showThoughts("3");
        }

        if (hour < 24 && flag == 0) {
            flag = 1;
            showThoughts("4");
        }
    }

    private void showThoughts(String s) {
        if (s.equals("1")){
            Toasty.normal(getApplicationContext(), "Good Night!").show();
        }
        if (s.equals("2")){
            Toasty.normal(getApplicationContext(), "Good Morning!").show();
        }
        if (s.equals("3")){
            Toasty.normal(getApplicationContext(), "Good Afternoon!").show();
        }
        if (s.equals("4")){
            Toasty.normal(getApplicationContext(), "Good Evening!").show();
        }
    }


    public void setActionBarTitle (String title){
        getSupportActionBar().setTitle(title);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Fragment f = getSupportFragmentManager().findFragmentById(R.id.fmain);
            if (f instanceof HomeFragment) {
                try {
                    SweetAlertDialog pDialog = new SweetAlertDialog(MainNavActivity.this, SweetAlertDialog.WARNING_TYPE);
                    pDialog.setTitleText("Really Exit");
                    pDialog.setContentText("Sure you want to exit");
                    pDialog.setConfirmText("Yes");
                    pDialog.setCancelText("No");
                    pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            Intent a = new Intent(Intent.ACTION_MAIN);
                            a.addCategory(Intent.CATEGORY_HOME);
                            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(a);
                            finishAffinity();
                        }
                    });
                    pDialog.setCancelClickListener(null);
                    pDialog.show();
                    pDialog.setCancelable(false);
                } catch (Exception x) {
                    new AlertDialog.Builder(this)
                            .setTitle("Really Exit")
                            .setMessage("Sure you want to exit")
                            .setNegativeButton(android.R.string.no, null)
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface arg0, int arg1) {
                                    Intent a = new Intent(Intent.ACTION_MAIN);
                                    a.addCategory(Intent.CATEGORY_HOME);
                                    a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(a);
                                    finishAffinity();
                                }
                            }).create().show();
                }
            }else{
                super.onBackPressed();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_nav, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            new SharedPref(getApplicationContext()).clearPref();
            Intent in = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(in);
            finish();
            return true;

        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fmain,  new AddAppointmentFragment()).addToBackStack("tag").commit();

        } else if (id == R.id.nav_gallery) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fmain,  new ViewAppointFragment()).addToBackStack("tag").commit();

        }
        else if (id == R.id.nav_home) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fmain,  new HomeFragment()).addToBackStack("tag").commit();

        }
        else if (id == R.id.nav_about) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fmain,  new AboutUsFragment()).addToBackStack("tag").commit();

        }
        else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {
            new SharedPref(getApplicationContext()).clearPref();
            Intent in = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(in);
            finish();


        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    /*public void autoUpdator() {


        final String appPackageName = getApplicationContext().getPackageName(); // getPackageName() from Context or Activity object

        StringRequest stringPostRequest = new StringRequest(Request.Method.POST, Config.URL_APPUpdator,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String stringResponse) {
                        try {
                            Log.v("stringResponse", "verosn " + stringResponse);

                            JSONObject response = new JSONObject(stringResponse);
                            String aa = response.getString("versioncode");
                            String bb = response.getString("importance");
                            Double var = 0.0;
                            try {
                                var = Double.parseDouble(aa);

                            } catch (Exception e) {
                                var = 0.0;
                            }


                            int version = 0;
                            try {
                                PackageInfo pInfo = getApplicationContext().getPackageManager().getPackageInfo(getApplicationContext().getPackageName(), 0);
                                version = pInfo.versionCode;

                            } catch (PackageManager.NameNotFoundException e) {
                                e.printStackTrace();
                            }


                            Double currentver = 0.0;
                            try {
                                currentver = Double.parseDouble(version + "");

                            } catch (Exception e) {
                                currentver = 0.0;


                            }

                            Log.v("version", "current" + currentver + " new :" + var);
                            if (var > currentver) {

                                updateDialog(bb);
                            }else{
                                editor.putString("UpdateLL","0");
                                editor.commit();
                            }

                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        //Toast.makeText(getApplicationContext(), "Could not connect", Toast.LENGTH_LONG).show();
                        Toasty.error(getApplicationContext(), "Could not connect").show();
                        Log.e("Volley", error.toString());
                    }
                }) {
            @Override
            protected java.util.Map<String, String> getParams() {
                java.util.Map<String, String> params = new HashMap<String, String>();
                params.put("adminid", "12");
                params.put("appPackageName", appPackageName);

                return params;
            }
        };

        RetryPolicy policy = new DefaultRetryPolicy(30000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringPostRequest.setRetryPolicy(policy);
        stringPostRequest.setShouldCache(false);
        MyApplication.getInstance().addToReqQueue(stringPostRequest);

    }

    private void updateDialog(final String bb) {
        editor.putString("UpdateLL","1");
        editor.commit();
        final android.support.v7.app.AlertDialog.Builder dialog = new android.support.v7.app.AlertDialog.Builder(getApplicationContext());
        dialog.setCancelable(false);
        dialog.setTitle("New Update available");
        dialog.setMessage("Please update your app ..!");
        dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

                editor.putString("UpdateLL","0");
                editor.commit();
                final String appPackageName = getApplicationContext().getPackageName(); // getPackageName() from Context or Activity object
                try {

                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(getResources().getString(R.string.urll)));
                    startActivity(intent);
                } catch (Exception e) {

                }
            }

        })
                .setNegativeButton("No ", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        if(bb.equals("0")){
                            dialog.dismiss();
                        }else {
                            Intent a = new Intent(Intent.ACTION_MAIN);
                            a.addCategory(Intent.CATEGORY_HOME);
                            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(a);
                            finishAffinity();
                            System.exit(0);
                        }
                    }
                });

        final android.support.v7.app.AlertDialog alert = dialog.create();
        alert.show();
        alert.setCanceledOnTouchOutside(false);
        alert.setCancelable(false);
    }*/

    /*@Override
    public void onPause() {
        if (adView != null) {
            adView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (adView != null) {
            adView.resume();
        }
    }

    @Override
    public void onDestroy() {
        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }*/
}
