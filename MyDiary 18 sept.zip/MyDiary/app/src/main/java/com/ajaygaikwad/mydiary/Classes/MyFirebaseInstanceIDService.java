package com.ajaygaikwad.mydiary.Classes;


import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import org.json.JSONException;
import org.json.JSONObject;


public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {
    private static final String TAG = "TestApplication";
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    //SessionManager sessionManager;

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    // [START refresh_token]
    @Override
    public void onTokenRefresh()
    {
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Refreshed token: " + refreshedToken);
        preferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        editor=preferences.edit();

        //new SharedPrefFireBaseId(this).setFirebaseId(refreshedToken);

        editor.putString("firebasetoken",refreshedToken).commit();

        //updateresttoken();

        //sessionManager.setfirebaseid(refreshedToken);
        //sessionManager.setfirebaseidfornoti(refreshedToken);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.

    }

    /*private void updateresttoken() {

        SyncHttpClient client = new SyncHttpClient();
        RequestParams params = new RequestParams();

        String et_id= new SharedPrefAccStatus(getApplicationContext()).getId();
        String firebase= new SharedPrefFireBaseId(this).getFirebaseId().toString().trim();
        // String login_with= new SharedPrefAccStatus(this).getLoginWith();
        //params.put("login_with", login_with);
        params.put("admin_id", et_id);
        params.put("firebasetoken",firebase);


        client.post(Config.urlupdatefirebasetoken, params, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, JSONObject response) {

                try {
                    String success = response.getString("success");
                    if (success.equals("1") ) {

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, String res, Throwable t) {
                // called when response HTTP status is "4XX" (eg. 401, 403, 404)
                Log.v("rest", "error");
                Toast.makeText(getApplicationContext(), "Connection Failed", Toast.LENGTH_LONG).show();
            }
        });

    }*/
    }
