package com.ajaygaikwad.mydiary;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ajaygaikwad.mydiary.Adapter.Adapter_Flat_Images;
import com.ajaygaikwad.mydiary.Classes.MyApplication;
import com.ajaygaikwad.mydiary.Classes.SharedPref;
import com.ajaygaikwad.mydiary.WebHelper.Config;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;

public class ViewPropDetailsActivity extends AppCompatActivity {

    TextView name_owner,owner_no,address_prop,address_prop2,area_sqmt,prop_price,des_kit,des_bath,des_bed,des_hall,des_other,o_name,o_no,tt_soc_name,prop_type;

    ImageView flat_img;
    String details,image1,image2,image3,image4,bhk,soc_name,flat_type;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    Button intrest_btn;
    private ProgressDialog progressBar;
    private int progressBarStatus;
    String PropID;
    LinearLayout ll_kit,ll_bath,ll_bed,ll_hall,ll_area,ll_soc_name;
    ImageView imgcall;
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static final Integer[] XMEN = new Integer[0];
    private ArrayList<Integer> XMENArray = new ArrayList<Integer>();
    String[] imageUrls;
    String intentpropID,intentPropType;
    ArrayList<String> imagearray = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_prop_details);

        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor=preferences.edit();
        setTitle("Property Details");
        //setupToolBar();
        Intent in = getIntent();
        intentpropID = in.getStringExtra("PropID");
        intentPropType = in.getStringExtra("PropType");
        //intentpropID


        init();
        getPropFromIDs();
        //bhk=new AllSharedPrefrences(getApplicationContext()).getBhk();
        soc_name = preferences.getString("soc_name", "");
        flat_type = preferences.getString("flat_type", "");

    }

        private void init() {
            address_prop=findViewById(R.id.address_prop);
            des_bath=findViewById(R.id.des_bath);
            des_bed=findViewById(R.id.des_bed);
            des_kit=findViewById(R.id.des_kit);
            des_hall=findViewById(R.id.des_hall);
            des_other=findViewById(R.id.des_other);
            area_sqmt=findViewById(R.id.area_sqmt);
            prop_price=findViewById(R.id.prop_price);
            intrest_btn=findViewById(R.id.intrest_btn);
            ll_kit=findViewById(R.id.ll_kit);
            ll_bath=findViewById(R.id.ll_bath);
            ll_bed=findViewById(R.id.ll_bed);
            ll_hall=findViewById(R.id.ll_hall);
            ll_area=findViewById(R.id.ll_area);
            o_name=findViewById(R.id.o_name);
            o_no=findViewById(R.id.o_no);
            imgcall=findViewById(R.id.imgcall);
            address_prop2=findViewById(R.id.address_prop2);
            ll_soc_name=findViewById(R.id.ll_soc_name);
            tt_soc_name=findViewById(R.id.tt_soc_name);
            prop_type=findViewById(R.id.prop_type);
            prop_type.setText(intentPropType);


            switch (intentPropType){

                case "Flat" :
                    ll_kit.setVisibility(View.VISIBLE);
                    ll_hall.setVisibility(View.VISIBLE);
                    ll_bed.setVisibility(View.VISIBLE);
                    ll_bath.setVisibility(View.VISIBLE);
                    break;
                case "House" :
                    ll_kit.setVisibility(View.VISIBLE);
                    ll_hall.setVisibility(View.VISIBLE);
                    ll_bed.setVisibility(View.VISIBLE);
                    ll_bath.setVisibility(View.VISIBLE);
                    break;
                case "Shop on Rent" :
                    ll_area.setVisibility(View.GONE);
                    break;
                case "Hall on Rent" :
                    ll_area.setVisibility(View.GONE);
                    break;
                case "Room on Rent" :
                    ll_area.setVisibility(View.GONE);
                    break;
            }

            mPager=findViewById(R.id.pager);

    }



        private void scroll_image() {

            for(int i=0;i<XMEN.length;i++)
                XMENArray.add(XMEN[i]);

            final ViewPager viewPager1 = findViewById(R.id.pager);
            Adapter_Flat_Images adapter1 = new Adapter_Flat_Images(this, imagearray);
            viewPager1.setAdapter(adapter1);
            CircleIndicator indicator1 = (CircleIndicator)findViewById(R.id.indicator);
            indicator1.setViewPager(viewPager1);

            // Auto start of viewpager
            final Handler handler = new Handler();
            final Runnable Update = new Runnable() {
                public void run() {
                    if (currentPage == XMEN.length) {
                        currentPage = 0;
                    }
                    viewPager1.setCurrentItem(currentPage++, true);
                }
            };
            Timer swipeTimer = new Timer();
            swipeTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    handler.post(Update);
                }
            }, 10000, 10000);

        }

    public void progressDiaglog(){
        progressBar = new ProgressDialog(ViewPropDetailsActivity.this);
        progressBar.setCancelable(false);
        progressBar.setMessage(getString(R.string.pleaseWait));
        progressBar.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressBar.setProgress(0);
        progressBar.setMax(100);
        progressBar.show();
        progressBarStatus = 0;
    }

    private void getPropFromIDs (){

        progressDiaglog();
        StringRequest postreq = new StringRequest(Request.Method.POST, Config.GET_PROP_FROM_IDs, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONObject jsonObject = new JSONObject(response);

                    JSONArray jsonArray = jsonObject.getJSONArray("jsonDetails");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject j1 = jsonArray.getJSONObject(i);
                        String propID = j1.getString("PropID");
                        String name = j1.getString("name");
                        String mobile = j1.getString("mobile");
                        String prop_address = j1.getString("prop_address");
                        String actual_price = j1.getString("actual_price");

                        if(!intentPropType.equals("Shop on rent") || !intentPropType.equals("Hall on rent") || !intentPropType.equals("Room on rent")){
                            String area_sqft = j1.getString("area_sqft");

                            area_sqmt.setText(area_sqft+" sqft");

                            if(intentPropType.equals("Farm")){
                                area_sqmt.setText(area_sqft+" acre");
                            }

                        }
                        if(intentPropType.equals("Flat") || intentPropType.equals("House")){
                            String des_kit1 = j1.getString("des_kit");
                            String des_hall1 = j1.getString("des_hall");
                            String des_bed1 = j1.getString("des_bed");
                            String des_bath1 = j1.getString("des_bath");

                            des_bath.setText(des_bath1);
                            des_bed.setText(des_bed1);
                            des_kit.setText(des_kit1);
                            des_hall.setText(des_hall1);
                        }
                        String image_one = j1.getString("image_one");
                        String image_two = j1.getString("image_two");
                        String image_three = j1.getString("image_three");
                        String image_four = j1.getString("image_four");
                        String description = j1.getString("description");
                        String full_address = j1.getString("full_address");

                        image1 = image_one;
                        image2 = image_two;
                        image3 = image_three;
                        image4 = image_four;

                        address_prop.setText(prop_address);
                        address_prop2.setText(full_address);
                        o_name.setText(name);
                        o_no.setText(mobile);

                        prop_price.setText(actual_price);
                        des_other.setText(description);


                    }
                    ArrayList<String> images = new ArrayList<String>();
                    images.add(Config.ip_image_address+image1);
                    images.add(Config.ip_image_address+image2);
                    images.add(Config.ip_image_address+image3);
                    images.add(Config.ip_image_address+image4);


                    for (int i = 0; i<images.size();i++){
                        imagearray.add(images.get(i));
                    }

                    imgcall.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Intent in = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel",o_no.getText().toString(), null));
                            startActivity(in);

                        }
                    });
                    scroll_image();

                    progressBar.dismiss();
                } catch (Exception e1) {
                    progressBar.dismiss();
                    Toast.makeText(getApplicationContext(), "Error retrive Ids", Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.dismiss();
                Toast.makeText(getApplicationContext(), "Error Connecting To Server", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<String, String>();

                map.put("propType", intentPropType);
                map.put("city",new SharedPref(getApplicationContext()).getCity());
                map.put("id",intentpropID);


                return map;
            }
        };
        MyApplication.getInstance().addToReqQueue(postreq);

    }

  


}
